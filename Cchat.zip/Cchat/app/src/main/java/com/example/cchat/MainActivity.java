package com.example.cchat;

import androidx.annotation.NonNull;
import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.icu.text.DateFormat;
import android.os.Build;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import com.firebase.ui.auth.AuthUI;
import com.firebase.ui.database.FirebaseListAdapter;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.FirebaseDatabase;

public class MainActivity extends AppCompatActivity {

    private static final int SIGN_IN_REQUEST_CODE = 1000;
    private Object Adapter = new FirebaseListAdapter<ChatMessage>(this, ChatMessage.class,
            R.layout.message,FirebaseDatabase.getInstance().getReference()){
        @Override
        protected void populateView(View v, ChatMessage model, int position) {

        }

        @RequiresApi(api = Build.VERSION_CODES.N)

        protected void populateview(View v,ChatMessage model, int position){
            TextView messageText=(TextView) v. findViewById(R.id.message_text);
            TextView messageUser=(TextView) v. findViewById(R.id.message_user);
            TextView messageTime= (TextView) v.findViewById(R.id.message_time);

            messageText.setText(model.getMessageText());
            messageUser.setText(model.getMessageText());

            messageTime.setText(model.getMessageText(), TextView.BufferType.valueOf(DateFormat.getDateInstance().format("dd-MM-yy (HH-mm-ss)")));
        }
    };

   // public MainActivity(Object view) {
     //   View = view;
    //}

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if(FirebaseAuth.getInstance().getCurrentUser()==null){
            startActivityForResult(
                    AuthUI.getInstance()
                    .createSignInIntentBuilder()
                    .build(),
                    SIGN_IN_REQUEST_CODE
            );
        }
        else {
            Toast.makeText(this, "Welcome " + FirebaseAuth.getInstance()
            .getCurrentUser()
            .getDisplayName(),
                    Toast.LENGTH_LONG)
                    .show();
            displayChatMessages();
        }

    }

    private void displayChatMessages() {
        ListView listViewofMessages=(ListView)findViewById(R.id.list_of_messages);
    }
    @Override
    protected void onActivityResult(int requestedCode, int resultCode, Intent data)
    {
        super.onActivityResult(requestedCode, resultCode, data);
        if (requestedCode==SIGN_IN_REQUEST_CODE){
            if(resultCode==RESULT_OK){
                Toast.makeText(this,
                "Successfully signed in. Welcome!", Toast.LENGTH_LONG)
                        .show();
                displayChatMessages();
            } else {
                Toast.makeText(this, "We couldn't sign you in. Please try again later",
                        Toast.LENGTH_LONG)
                        .show();
                finish();
            }
        }
    }
    @Override
    public boolean onCreateOptionsMenu(Menu menu){
        getMenuInflater().inflate(R.menu.main_menu,menu);
        return true;
    }
    @Override
    public boolean onOptionsItemSelected(MenuItem item){
        if(item.getItemId()==R.id.menu_sign_out){
            AuthUI.getInstance().signOut(this)
                    .addOnCompleteListener(new OnCompleteListener<Void>() {
                        @Override
                        public void onComplete(@NonNull Task<Void> task) {
                            Toast.makeText(MainActivity.this,
                                    "YOu have been signed out",
                                    Toast.LENGTH_LONG)
                                    .show();
                            finish();
                        }
                    });
        }return true;
    }
    FloatingActionButton fab=(FloatingActionButton) findViewById(R.id.fab);
    fab.setOnClickListener(new View.OnClickListener())
    private final Object View = null;

    {
        Object view;
        EditText input=(EditText) findViewById(R.id.input);
        FirebaseDatabase.getInstance()
                .getReference()
                .push()
                .setValue(new ChatMessage(input.getText().toString(),
                        FirebaseAuth.getInstance()
                .getCurrentUser()
                .getDisplayName()
                ));
        input.setText("");
    }
}
